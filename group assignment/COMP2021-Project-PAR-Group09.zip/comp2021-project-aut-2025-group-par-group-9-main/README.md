# SEF-Project starter repository Autumn 2025

## Brief Project Documentation
Add the required details as listed in the Project Specification

### Group Name:
Group 9

----

### Group Member List:
List the **names** and **Student ID** for each team member.

1. **Urvesh Patel - 22110953**:
2. **Ismail Ather Mohammed - 22149587**:
3. **Kartikey Sachdeva - 22122045**:
4. **Student 4**:

----  

### Installation and setup instructions.
Detail any relevant instructions that the marker will need to follow to set up your Django project for marking.

1.  Fixed git
2.
3.
4.

----

### Brief user guide for using the application.
#### Landing Page

----

#### Main web pages and their purpose

- **Home Page**:
The purpose of the home page is to act as the initial starting point for the web application for users to navigate.

- **User Registration Form**:
The purpose of the user registration from is to allow the user to register/create an account for more access.

- **User Login Form**:
The purpose of the user login form is to allow users who have already registered/created an account to login to that account.

- **User Profile Form**:
The purpose of the user profile form is for the user to manage their profile and preferences.

- **Trail Submission Form**:
The purpose of the trail submission form is to stylise the users trail and upload it onto the web applicatiom.

- **Trail Review & Rating Form**:
The purpose of the trail review and rating form is for other users to review and rate the uploaders trail.

- **Trail Search & Filtering Form**:
The purpose of the trail search and filtering form is for users to search for a specific trail they are looking for.

- **Comment Form**:
The purpose of the comment form is to comment on a trail.

- **Admin Trail Approval Form**:
The purpose of the admin trail approval form is to allow admins to filter out trail uploads by approving for disapproving them.

- **User Management Form**:
The purpose of the user management form is to manage the user's status.

- **Report Content Review Form**:
The purpose of the report content review form is to review the reported content.
----
#### User credentials and their associated roles.
Ensure that the passwords are listed in **plain text**. All users that you have created in your database **must** be included.

-
-
-
----
