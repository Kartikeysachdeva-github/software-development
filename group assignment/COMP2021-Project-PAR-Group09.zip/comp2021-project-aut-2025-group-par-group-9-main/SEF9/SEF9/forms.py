from django import forms
from .models import Trail, Accessibility, TrailCondition, TrailComments, Trail_Review
from .models import User as Web_User
from .models import User


class TrailForm(forms.ModelForm):
    accessibility = forms.ModelMultipleChoiceField(
        queryset=Accessibility.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )
    trail_conditions = forms.ModelMultipleChoiceField(
        queryset=TrailCondition.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )

    class Meta:
        model = Trail
        fields = [
            'name', 'location', 'gps_coordinates', 'start_point', 'end_point', 'distance',
            'elevation_gain', 'difficulty_level', 'trail_type', 'estimated_time', 'user_notes',
            'accessibility', 'trail_conditions', 'photo'
        ]

class WebUserForm(forms.ModelForm):
    class Meta:
        model = Web_User
        fields = ['username', 'email', 'password']

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if Web_User.objects.filter(username=username).exists():
            raise forms.ValidationError("Username already exists.")
        return username
        

class TrailCommentForm(forms.ModelForm):
    class Meta:
        model = TrailComments
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={'placeholder': 'Add a comment...', 'rows': 2}),
        }

from .models import Trail_Review, Trail_Report  # ADD this import

# Existing forms remain unchanged...

class TrailReviewForm(forms.ModelForm):
    class Meta:
        model = Trail_Review
        fields = ['review_text', 'rating']
        widgets = {
            'review_text': forms.Textarea(attrs={'placeholder': 'Add a comment...', 'rows': 3}),
            'rating': forms.Select(choices=[(i, str(i)) for i in range(1, 6)])
        }


class TrailReportForm(forms.ModelForm):
    class Meta:
        model = Trail_Report
        fields = ['report_type', 'reason']
        widgets = {
            'report_type': forms.CheckboxSelectMultiple(choices=Trail_Report.REPORT_CHOICES),
            'reason': forms.Textarea(attrs={'placeholder': 'Reason for report...'}),
        }
       
class EditProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username','email', 'password']
   