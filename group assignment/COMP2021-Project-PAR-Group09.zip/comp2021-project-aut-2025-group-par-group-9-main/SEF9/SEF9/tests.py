from django.test import TestCase, Client
from django.urls import reverse
from .models import User, Trail, Trail_Review, TrailReportComment
from .forms import TrailForm, WebUserForm, TrailReportCommentForm

class UserModelTest(TestCase):
    def test_user_fields(self):
        user = User.objects.create(username="testuser", email="test@example.com", password="pass")
        self.assertEqual(user.username, "testuser")
        self.assertEqual(user.email, "test@example.com")

    def test_user_trail_relationship(self):
        user = User.objects.create(username="testuser2", email="test2@example.com", password="pass")
        trail = Trail.objects.create(name="Test Trail", submitted_by=user)
        self.assertEqual(trail.submitted_by, user)

class TrailReviewModelTest(TestCase):
    def test_review_fields(self):
        user = User.objects.create(username="reviewer", email="reviewer@example.com", password="pass")
        trail = Trail.objects.create(name="Trail for Review", submitted_by=user)
        review = Trail_Review.objects.create(trail_id=trail, user_id=user, rating=4, review_text="Nice!")
        self.assertEqual(review.rating, 4)
        self.assertEqual(review.review_text, "Nice!")

    def test_review_trail_relationship(self):
        user = User.objects.create(username="reviewer2", email="reviewer2@example.com", password="pass")
        trail = Trail.objects.create(name="Trail2", submitted_by=user)
        review = Trail_Review.objects.create(trail_id=trail, user_id=user, rating=5)
        self.assertEqual(review.trail_id, trail)

class TrailDetailViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create(username="user", email="user@example.com", password="pass")
        self.trail = Trail.objects.create(name="TrailView", submitted_by=self.user)

    def test_trail_detail_get(self):
        response = self.client.get(reverse('trail_detail', args=[self.trail.trail_id]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "TrailView")

    def test_trail_detail_guest_flag(self):
        session = self.client.session
        session['is_guest'] = True
        session.save()
        response = self.client.get(reverse('trail_detail', args=[self.trail.trail_id]))
        self.assertContains(response, "Back")  # Button logic

class TrailSubmissionViewTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create(username="submitter", email="submitter@example.com", password="pass")

    def test_trail_submission_get(self):
        session = self.client.session
        session['user_id'] = self.user.user_id
        session.save()
        response = self.client.get(reverse('TrailSumbting'))
        self.assertEqual(response.status_code, 200)

    def test_trail_submission_guest_redirect(self):
        session = self.client.session
        session['is_guest'] = True
        session.save()
        response = self.client.get(reverse('TrailSumbting'))
        self.assertEqual(response.status_code, 302)  # Should redirect

class TrailFormTest(TestCase):
    def setUp(self):
        self.user = User.objects.create(username="trailuser", email="trailuser@example.com", password="pass")

    def test_trail_form_valid(self):
        form_data = {
            'name': 'Trail1',
            'location': 'Location1',
            'distance': 5,
            'elevation_gain': 100,
            'difficulty_level': 'Beginner',
            'trail_type': 'Loop',
            'estimated_time': '1 hour',
            'user_notes': 'Nice trail',
        }
        form = TrailForm(data=form_data)
        self.assertTrue(form.is_valid())

    def test_trail_form_invalid_missing_name(self):
        form_data = {
            'location': 'Location1',
            'distance': 5,
        }
        form = TrailForm(data=form_data)
        self.assertFalse(form.is_valid())

    def test_trail_form_invalid_distance(self):
        form_data = {
            'name': 'Trail2',
            'location': 'Location2',
            'distance': -1,  # Invalid
        }
        form = TrailForm(data=form_data)
        self.assertFalse(form.is_valid())