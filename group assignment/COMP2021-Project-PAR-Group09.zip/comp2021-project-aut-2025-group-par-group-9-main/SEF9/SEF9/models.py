from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


# Difficulty levels
difficulty_choices = [
        ('Beginner','Beginner'),
        ('Intermediate','Intermediate'),
        ('Advanced','Advanced'),
    ]

# Trail type

trail_types = [
        ('Loop','Loop'),
        ('Out & Back','Out & Back'),
        ('Point to Point','Point to Point')
    ]

approval_choices = [
        ('Approved','Approved'),
        ('Pending','Pending'),
        ('Rejected','Rejected')
]

#Table for User Data (Ismail)
class User(models.Model):
    user_id = models.AutoField(
        primary_key=True,
        help_text="Unique identifier for the user")
    
    username = models.CharField(
        max_length=50, 
        unique=True,
        help_text="Username of the user",
        null=True,
        blank=True)

    
    # first_name = models.CharField(
    #     max_length=50,
    #     help_text="Firstname of the user",
    #     null=True,
    #     blank=True
    # )
    
    # last_name = models.CharField(
    #     max_length=50,
    #     help_text="last name of user",
    #     null=True,
    #     blank=True
    # )
    
    email = models.EmailField(
        unique=True,
        help_text="Email address of the user",
        null=True,
        blank=True
    )
    
    password = models.CharField(
        max_length=128,
        help_text="Password of the user",
        null=True,
        blank=True
    )
    
    account_status = models.BooleanField(
        default=True,
        help_text="Account status wheather its active or not"
    )
    
    date_registered = models.DateTimeField(
        auto_now_add=True,
        help_text="date registered",
        null=True,
        blank=True
    )
    
    last_login = models.DateTimeField(
        null=True,
        blank=True
    )
    
    is_admin = models.BooleanField(
        default=False,
        help_text="Whether the user is an admin or not"
    )


class Trail_Report(models.Model):
    REPORT_CHOICES = (
        ('trail', 'Trail'),
        ('user', 'User'),
    )

    report_id = models.AutoField(primary_key=True)
    trail = models.ForeignKey('Trail', on_delete=models.CASCADE)
    user = models.ForeignKey('User', on_delete=models.CASCADE)
    reason = models.TextField()
    report_type = models.CharField(max_length=10, choices=REPORT_CHOICES)
    date_submitted = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Report by {self.user.username} on {self.trail.name}"

class Trail_Review(models.Model):
    review_id = models.AutoField(
        primary_key=True,
        help_text="Unique identifier for the review"
    )
    
    trail_id = models.ForeignKey(
        'Trail',
        on_delete=models.CASCADE,
        related_name='reviews',
        help_text="Trail ID for the review"
    )
    
    user_id = models.ForeignKey(
        'User',
        on_delete=models.CASCADE,
        related_name='review_given_by',
        null=True,
        blank=True
    )
    
    rating = models.IntegerField(
        default=0,
        null=True,
        blank=True
    )
    
    review_text = models.TextField(
        blank=True,
        null=True
    )
    
    date_submitted = models.DateTimeField(
        auto_now_add=True,
        help_text="Date and time when the trail was submitted",
        null=True,
        blank=True
    )

class Trail(models.Model):
    trail_id = models.AutoField(
        primary_key=True,
        help_text="Unique identifier for the trail"
    )
    
    
    name = models.CharField(
        max_length=100,
        help_text="Name of the trail",
        null=True,
        blank=True
    )
    
    location = models.CharField(
        max_length=100,
        help_text="Location of the trail",
        null=True,
        blank=True
    )
    
    gps_coordinates = models.CharField(
        max_length=100,
        help_text="GPS coordinates of the trail",
        null=True,
        blank=True
    )
    
    start_point = models.CharField(
        max_length=100,
        help_text="Starting point of the trail",
        null=True,
        blank=True
    )
    
    end_point = models.CharField(
        max_length=100,
        help_text="Ending point of the trail",
        null=True,
        blank=True
    )
    
    distance = models.FloatField(
        default=0.0,
        help_text="Distance in kilometers",
        null=True,
        blank=True
    )
    
    elevation_gain = models.FloatField(
        default=0.0,
        help_text="Elevation gain in meters",
        null=True,
        blank=True
    )

    difficulty_level = models.CharField(
        max_length=12,
        choices=difficulty_choices,
        default='Beginner',
        help_text="Difficulty level of the trail",
        null=True,
        blank=True
    )

    trail_type = models.CharField(
        max_length=15,
        choices=trail_types,
        default='Loop',
        help_text="Type of the trail",
        null=True,
        blank=True
    )

    estimated_time = models.CharField(
        max_length=50,
        default='0',
        help_text="Estimated time to complete the trail",
        null=True,
        blank=True
    )

    user_notes = models.TextField(
        blank=True,
        null=True,
        help_text="User notes about the trail"
    )   

    submitted_by = models.ForeignKey(
        'User',
        on_delete=models.CASCADE,
        null=True,
        related_name='submitted_by',
        help_text="User who submitted the trail",
        blank=True
    )
    
    approval_status = models.CharField(
        max_length=10,
        choices=approval_choices,
        default='Pending',
        help_text="Approval status of the trail",
        null=True,
        blank=True
    )

    admin_notes = models.TextField( 
        blank=True,
        null=True,
        help_text="Admin notes about the trail"
    )

    date_submitted = models.DateTimeField(
        auto_now_add=True,
        help_text="Date and time when the trail was submitted",
        null=True,
        blank=True
    )

    reviewed_by = models.ForeignKey(
        'User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='reviewed_trails',
        help_text="Admin who reviewed the trail"
    )

    accessibility = models.ManyToManyField('Accessibility', blank=True)
    trail_conditions = models.ManyToManyField('TrailCondition', blank=True)
    photo = models.ImageField(upload_to='images/', blank=True, null=True)

class Accessibility(models.Model):
    name = models.CharField(max_length=50, unique=True)
    def __str__(self):
        return self.name

class TrailCondition(models.Model):
    name = models.CharField(max_length=50, unique=True)
    def __str__(self):
        return self.name

class TrailComments(models.Model):
    trail = models.ForeignKey(Trail, on_delete=models.PROTECT)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"Comment by {self.user.username} on {self.trail.name}"