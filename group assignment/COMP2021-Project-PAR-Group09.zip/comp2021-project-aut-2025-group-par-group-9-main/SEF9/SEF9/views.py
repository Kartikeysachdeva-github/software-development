from django.shortcuts import render, redirect, get_object_or_404
from .forms import TrailForm
from .forms import WebUserForm
from .models import User
from .forms import EditProfileForm
from django.contrib.auth.hashers import make_password
from .models import Trail, Accessibility, TrailCondition
from django.db.models import Q
from .forms import TrailCommentForm
from .models import TrailComments
from .models import Trail, Trail_Review, Trail_Report
from .forms import TrailReviewForm, TrailReportForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages


def starting_page(request):
    show_login = request.GET.get('show_login', False)
    return render(request, 'startingpage.html', {'show_login': show_login})
 
def profile(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('home')
    user = User.objects.get(user_id=user_id)
    if request.method == 'POST':
        form = EditProfileForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('profile')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = EditProfileForm(instance=user)
    return render(request, 'profile.html', {'user': user, 'form': form})

def profileAdmin(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('home')
    user = User.objects.get(user_id=user_id)
    if request.method == 'POST':
        form = EditProfileForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully!")
            return redirect('profileAdmin')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = EditProfileForm(instance=user)
    return render(request, 'profileAdmin.html', {'user': user, 'form': form})
        

def TrailSearchGuest(request):
    request.session['is_guest'] = True  # Set guest session
    accessibility_list = Accessibility.objects.all()
    condition_list = TrailCondition.objects.all()
    return render(request, 'TrailSearchAndFilteringFormForGuest.html', {
        'accessibility_list': accessibility_list,
        'condition_list': condition_list,
    })

def TrailSearch(request):
    request.session['is_guest'] = False  # Not a guest
    accessibility_list = Accessibility.objects.all()
    condition_list = TrailCondition.objects.all()
    return render(request, 'TrailSearchAndFilteringForm.html', {
        'accessibility_list': accessibility_list,
        'condition_list': condition_list,
    })

def TrailSumbting(request):
    if request.session.get('is_guest', False):
        messages.error(request, "Guests cannot submit trails. Please register or log in.")
        return redirect('TrailSearchGuest')
    if request.method == 'POST':
        form = TrailForm(request.POST, request.FILES)
        if form.is_valid():
            trail = form.save(commit=False)
            user_id = request.session.get('user_id')
            if user_id:
                from .models import User
                try:
                    trail.submitted_by = User.objects.get(user_id=user_id)
                except User.DoesNotExist:
                    trail.submitted_by = None
            trail.save()
            form.save_m2m()
            messages.success(request, "Trail submitted successfully!")
            return redirect('profile')
    else:
        form = TrailForm()
    return render(request, 'TrailSubmissionForm.html', {'form': form})

def Commment(request):
    return render(request, 'CommentForm.html')

def TrailRating(request):
    if request.session.get('is_guest', False):
        messages.error(request, "Guests cannot rate trails. Please register or log in.")
        return redirect('TrailSearchGuest')
    # Add form handling logic here if needed
    return render(request, 'TrailReviewAndRatingForm.html')

def AdminTrailReview(request):
    if request.method == "POST":
        trail_id = request.POST.get("trail_id")
        approval_status = request.POST.get("approval_status")
        if trail_id and approval_status:
            try:
                trail = Trail.objects.get(trail_id=trail_id)
                trail.approval_status = approval_status
                trail.save()
            except Trail.DoesNotExist:
                pass  # Optionally handle error
        return redirect('AdminTrailReview')  # Refresh page

    # Show all trails, not just pending
    trails = Trail.objects.filter(approval_status__in=['Pending', 'Rejected'])
    return render(request, 'AdminTrailApprovalForm.html', {'trails': trails})

def reportedContent(request):
    if not request.session.get('is_admin', False):
        messages.error(request, "Access denied. Admins only.")
        return redirect('profile')  # or any non-admin fallback page

    if request.method == 'POST':
        report_id = request.POST.get('report_id')
        action = request.POST.get('action')
        if report_id and action == 'resolve':
            try:
                report = Trail_Report.objects.get(pk=report_id)
                report.delete()
            except Trail_Report.DoesNotExist:
                pass
        return redirect('reportedContent')

    reports = Trail_Report.objects.all().order_by('-date_submitted')
    return render(request, 'ReportedContentReviewForm.html', {'reports': reports})

def trail_detail(request, trail_id):
    trail = Trail.objects.get(pk=trail_id)
    comments = TrailComments.objects.filter(trail=trail).order_by('-created_at')
    comment_form = TrailCommentForm()
    review_form = TrailReviewForm()
    report_form = TrailReportForm()

    if request.method == 'POST' and 'add_comment' in request.POST:
        comment_form = TrailCommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.trail = trail
            if request.user.is_authenticated:
                comment.user = request.user
            comment.save()
            return redirect('trail_detail', trail_id=trail_id)
        
    success = request.GET.get("success", "")

    return render(request, 'trail_detail.html', {
        'trail': trail,
        'comments': comments,
        'comment_form': comment_form,
        'review_form': review_form,
        'report_form': report_form,
        'success_type': success,
    })

def userMnagement(request):
    return render(request, 'UserManagementForm.html')

def success_Register(request):
    return render(request, 'success_Register.html')

def searchResults(request):
    name = request.GET.get('name', '')
    location = request.GET.get('location', '')
    difficulty = request.GET.get('difficulty', '')
    trail_type = request.GET.get('trailType', '')

    trails = Trail.objects.filter(approval_status='Approved')

    # Text search
    if name:
        trails = trails.filter(name__icontains=name)
    if location:
        trails = trails.filter(location__icontains=location)
    if difficulty:
        trails = trails.filter(difficulty_level__iexact=difficulty)
    if trail_type:
        trails = trails.filter(trail_type__icontains=trail_type)

    accessibility_ids = request.GET.getlist('accessibility')
    if accessibility_ids:
        trails = trails.filter(accessibility__id__in=accessibility_ids).distinct()

    condition_ids = request.GET.getlist('trail_conditions')
    if condition_ids:
        trails = trails.filter(trail_conditions__id__in=condition_ids).distinct()

    is_guest = request.session.get('is_guest', False)
    is_admin = request.session.get('is_admin', False)

    return render(request, 'searchResults.html', {
        'trails': trails,
        'is_guest': is_guest,
        'is_admin': is_admin,
    })

#Ismail part (Not sure if this is correct)
#ISmail part modified by Urvesh to modelform
#Registration for Guests:
def register_user(request):
    if request.method == 'POST':
        form = WebUserForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.password = make_password(form.cleaned_data['password'])
            user.save()
            request.session['is_guest'] = False
            messages.success(request, "Registration successful. Please log in.")
            return redirect('success_Register')
    else:
        form = WebUserForm()
    return render(request, 'startingpage.html', {'form': form, 'show_signup': True})

#Login for Registered Users:
from django.contrib.auth.hashers import check_password
from .models import User as Web_User
from django.contrib import messages

def login_user(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            user = Web_User.objects.get(email=email)
            if check_password(password, user.password):
                request.session['user_id'] = user.user_id
                request.session['is_admin'] = user.is_admin
                request.session['is_guest'] = False
                messages.success(request, "Login successful.")
                if user.is_admin:
                    return redirect('profileAdmin')
                else:
                    return redirect('profile')
            else:
                messages.error(request, "Either email or password is incorrect.")
        except Web_User.DoesNotExist:
            messages.error(request, "Email not found.")
        return render(request, 'startingpage.html', {'show_login': True})
    return render(request, 'startingpage.html', {'show_login': True})


@login_required
def submit_review(request, trail_id):
    trail = get_object_or_404(Trail, pk=trail_id)
    if request.method == 'POST':
        form = TrailReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.trail_id = trail
            review.user_id = request.user  # using the logged-in user
            review.save()
            return redirect(f'/trail/{trail_id}/?success=review')
    return redirect('trail_detail', trail_id=trail_id)


@login_required
def submit_report(request, trail_id):
    trail = get_object_or_404(Trail, pk=trail_id)
    if request.method == 'POST':
        form = TrailReportForm(request.POST)
        if form.is_valid():
            for rtype in form.cleaned_data['report_type']:
                Trail_Report.objects.create(
                    trail=trail,
                    user=request.user,
                    reason=form.cleaned_data['reason'],
                    report_type=rtype
                )
            return redirect(f'/trail/{trail_id}/?success=report')
    return redirect('trail_detail', trail_id=trail_id)

from .models import Trail_Report

def reports_page(request):
    # if not request.session.get('is_admin', False):
    #     messages.error(request, "Access denied. Admins only.")
    #     return redirect('profile')

    reports = Trail_Report.objects.select_related('trail', 'user').order_by('-date_submitted')
    return render(request, 'reports.html', {'reports': reports})
