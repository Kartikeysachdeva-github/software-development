from django.contrib import admin
from .models import Trail 
from .models  import User
from .models import Trail_Review
from .models import Accessibility, TrailCondition, Trail_Report # Import the Trail model

admin.site.register(Trail)
admin.site.register(User)
admin.site.register(Trail_Review)
admin.site.register(Accessibility)
admin.site.register(TrailCondition)
admin.site.register(Trail_Report)  

