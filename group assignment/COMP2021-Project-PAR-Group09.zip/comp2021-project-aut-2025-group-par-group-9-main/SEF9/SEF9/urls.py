"""
URL configuration for SEF9 project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from SEF9 import views

urlpatterns = [
    path('', views.starting_page, name='home'),
    path('profile/',views.profile, name='profile'),
    path('profileAdmin/',views.profileAdmin, name='profileAdmin'),
    path('TrailSearchGuest/',views.TrailSearchGuest, name='TrailSearchGuest'),
    path('TrailSearch/',views.TrailSearch, name='TrailSearch'),
    path('TrailSumbting/',views.TrailSumbting, name='TrailSumbting'),
    path('Commment/',views.Commment, name='Commment'),
    path('TrailReview/',views.TrailRating, name='TrailReview'),
    path('AdminTrailReview/',views.AdminTrailReview, name='AdminTrailReview'),
    path(' reportedContent/',views.reportedContent, name='reportedContent'),
    path('admin/', admin.site.urls),
    path('userMnagement/',views.userMnagement, name='userMnagement'),
    path('register/', views.register_user, name='register_user'),
    path('searchResults/', views.searchResults, name = 'searchResults'),
    path('successregister/', views.success_Register, name='success_Register'),
    path('trail_detail/<int:trail_id>/', views.trail_detail, name='trail_detail'),
    path('login/', views.login_user, name='login_user'),
    path('trail/<int:trail_id>/submit_review/', views.submit_review, name='submit_review'),
    path('trail/<int:trail_id>/submit_report/', views.submit_report, name='submit_report'),
    path('reports/', views.reports_page, name='reports_page')



]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
