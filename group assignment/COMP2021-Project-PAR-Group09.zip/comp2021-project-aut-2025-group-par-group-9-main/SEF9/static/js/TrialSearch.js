console.log("Form submission prevented due to validation errors.");
document.getElementById("trailSearchForm").addEventListener("submit", function(e) {
    let isCorrect = true;

    const trailName = document.getElementById("trailName3").value.trim();
    const location = document.getElementById("location2").value.trim();
    const difficultyLevel = document.getElementById("difficultyLevel2").value;
    const minRange = document.getElementById("minRange").value.trim();
    const maxRange = document.getElementById("maxRange").value.trim();
    const trailType = document.getElementById("trailType2").value;

    const trailNameError = document.getElementById("trailNameError");
    const locationError = document.getElementById("locationError");
    const difficultyError = document.getElementById("difficultyError");
    const distanceError = document.getElementById("distanceError");
    const trailTypeError = document.getElementById("trailTypeError");
    const trailConditionError = document.getElementById("trailConditionError");
    const accessibilityError = document.getElementById("accessibilityError");

    const alphaNumericPattern = /^[a-zA-Z0-9\s\-]+$/;

    trailNameError.textContent = "";
    locationError.textContent = "";
    difficultyError.textContent = "";
    distanceError.textContent = "";
    trailTypeError.textContent = "";
    trailConditionError.textContent = "";
    accessibilityError.textContent = "";

    // Validating Trail Name
    if (!trailName){
        trailNameError.textContent = "Please enter a Trail Name.";
        isCorrect = false;
    }
    if (trailName.length > 0 && !alphaNumericPattern.test(trailName)) {
        trailNameError.textContent = "Trail Name may contain only letters, numbers, spaces, and hyphens.";
        isCorrect = false;
    }

    // Validating Location
    if (location.length > 0 && !alphaNumericPattern.test(location)) {
        locationError.textContent = "Location may contain only letters, numbers, spaces, and hyphens.";
        isCorrect = false;
    }

    // Validating Distance Range
    if ((minRange && (isNaN(minRange) || minRange <= 0)) || (maxRange && (isNaN(maxRange) || maxRange <= 0))) {
        distanceError.textContent = "Distance values must be positive numbers.";
        isCorrect = false;
    }

    if (!isCorrect) {
        e.preventDefault();
    } 
});