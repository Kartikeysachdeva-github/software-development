document.getElementById("AdminTrailApproval").addEventListener("submit", function(e) {
    let isCorrect = true;

    const trailName = document.getElementById("trailName").value.trim();
    const approvalStatus = document.getElementById("approvalStatus").value;
    const adminComments = document.getElementById("adminComments").value.trim();


    const trailNameError = document.getElementById("trailNameError");
    const approvalStatusError = document.getElementById("approvalStatusError");
    const adminCommentsError = document.getElementById("adminCommentsError");

    trailNameError.textContent = "";
    approvalStatusError.textContent = "";
    adminCommentsError.textContent = "";

    const trailNamePattern = /^[a-zA-Z0-9\s\-]+$/;
    const adminCommentPattern = /^[a-zA-Z0-9\s\.,\-]*$/;

    // Validating Trail Name Length
    if (trailName.length > 0 && !trailNamePattern.test(trailName)) 
    {
        trailNameError.textContent = "Trail Name may contain only letters, numbers, spaces, and hyphens.";
        isCorrect = false;
    }

    // Validating Trail Name
    if(!trailName)
    {
        trailNameError.textContent = "Please enter a Trail Name.";
        isCorrect = false;
    }

    // Validating Approval Status
    if (!approvalStatus) 
    {
        approvalStatusError.textContent = "Please select an Approval Status.";
        isCorrect = false;
    }

    // Validating Admin Comments Length
    if(adminComments.length > 0 && !adminCommentPattern.test(adminComments))
        {
            adminCommentsError.textContent = "Admin Comments may contain only letters, numbers, spaces, and punctuation.";
            isCorrect = false;
        }
    
    // Final Check
    if (!isCorrect) 
    {
        e.preventDefault();
    }
    else
    {
        alert("Trail approved successfully!");
    }
});
