// Sign In:
document.addEventListener("DOMContentLoaded", function () {
    const signInForm = document.querySelector(".signIN form");

    signInForm.addEventListener("submit", function (e) {
        let isValid = true;

        const email = document.getElementById("emailSignIn").value.trim();
        const password = document.getElementById("passwordSignIn").value;
        const emailErrorSignIn = document.getElementById("emailErrorSignIn");
        

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Validate Email
        emailErrorSignIn.textContent = "";
        if(!email)
        {
            emailErrorSignIn.textContent = "Please enter an email address.";
            isValid = false;
        }
        else if (!emailPattern.test(email)) {
            emailErrorSignIn.textContent = "Please enter a valid email address.";
            isValid = false;
        }

        if (!isValid) {
            e.preventDefault();
        } 
    });
});
