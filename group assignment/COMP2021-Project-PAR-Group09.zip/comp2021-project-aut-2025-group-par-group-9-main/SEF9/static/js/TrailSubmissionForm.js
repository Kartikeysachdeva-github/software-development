document.getElementById("trailSubmissionForm").addEventListener("submit", function(e) {
    let isCorrect = true;

    const trailName = document.getElementById("trailName").value.trim();
    const location = document.getElementById("location").value.trim();
    const gpsCoordinates = document.getElementById("gpsCoordinates").value.trim();
    const startLocation = document.getElementById("startLocation").value.trim();
    const endLocation = document.getElementById("endLocation").value.trim();
    const distance = document.getElementById("distance").value.trim();
    const elevationGain = document.getElementById("elevationGain").value.trim();
    const difficultyLevel = document.getElementById("difficultyLevel").value.trim();
    const trailType = document.getElementById("trailType").value.trim();
    const estimatedTime = document.getElementById("estimatedTime").value.trim();
    const userNotes = document.getElementById("userNotes").value.trim();
    const trailConditions = document.getElementById("trailConditions").value.trim();

    const alphabetsPattern = /^[a-zA-Z0-9\s\-]+$/;
    const coordinatesPattern = /^-?\d{1,2}(\.\d+)?,\s*-?\d{1,3}(\.\d+)?$/;
    const notesPattern = /^[a-zA-Z0-9\s.,\-]*$/;

    trailNameError.textContent = "";
    locationError.textContent = "";
    gpsCoordinatesError.textContent = "";
    startLocationError.textContent = "";
    endLocationError.textContent = "";
    distanceError.textContent = "";
    elevationGainError.textContent = "";
    difficultyLevelError.textContent = "";
    trailTypeError.textContent = "";
    estimatedTimeError.textContent = "";
    userNotesError.textContent = "";
    trailConditionsError.textContent = "";

    // Validating Trail Name Length
    if(!trailName)
    {
        trailNameError.textContent = "Please enter a Trail Name.";
        isCorrect = false;
    } else if (!alphabetsPattern.test(trailName)) {
        trailNameError.textContent = "Trail Name may contain only letters, numbers, spaces, and hyphens.";
        isCorrect = false;
    }

    // Validating Location
    if (!location) {
        locationError.textContent = "Please enter a Location.";
        isCorrect = false;
    } else if (!alphabetsPattern.test(location)) {
        locationError.textContent = "Location may contain only letters, numbers, spaces, and hyphens.";
        isCorrect = false;
    }

    // Validating GPS Coordinates
    if (!gpsCoordinates) {
        gpsCoordinatesError.textContent = "Please enter GPS Coordinates.";
        isCorrect = false;
    } else if (!coordinatesPattern.test(gpsCoordinates)) {
        gpsCoordinatesError.textContent = "GPS Coordinates must be in the format: latitude, longitude.";
        isCorrect = false;
    }

    if (!isCorrect) {
        e.preventDefault();
      } else {
        alert("Trail Added successfully");
      }

});