document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("trailSubmissionForm");
    const alphaNumericPattern = /^[a-zA-Z0-9\s\-]+$/;

    form.addEventListener("submit", function (e) {
        let isValid = true;

        // Trail Name Validation
        const trailName = document.getElementById("trailName").value.trim();
        const trailNameError = document.getElementById("trailNameError");
        trailNameError.textContent = ""; // Clear previous error
        if (!trailName) {
            trailNameError.textContent = "Trail Name is required.";
            isValid = false;
        }
        else if (!alphaNumericPattern.test(trailName)) {
            trailNameError.textContent = "Trail Name may contain only letters, numbers, spaces, and hyphens.";
            isValid = false;
        }

        // Location Validation
        const location = document.getElementById("location").value.trim();
        const locationError = document.getElementById("locationError");
        locationError.textContent = ""; // Clear previous error
        if (!location) {
            locationError.textContent = "Location is required.";
            isValid = false;
        }
        else if (!alphaNumericPattern.test(location)) {
            locationError.textContent = "Location may contain only letters, numbers, spaces, and hyphens.";
            isValid = false;
        }
         // trial start location Validation
        const startLocation = document.getElementById("startLocation").value.trim();
        const startLocationError = document.getElementById("startLocationError");
        startLocationError.textContent = ""; // Clear previous error
        if (!startLocation) {
            startLocationError.textContent = "Start Location is required.";
            isValid = false;
        }
        else if (!alphaNumericPattern.test(startLocation)) {
            startLocationError.textContent = "Start Location may contain only letters, numbers, spaces, and hyphens.";
            isValid = false;
        }
        // trial end location Validation
        const endLocation = document.getElementById("endLocation").value.trim();
        const endLocationError = document.getElementById("endLocationError");
        endLocationError.textContent = ""; // Clear previous error
        if (!endLocation) {
            endLocationError.textContent = "End Location is required.";
            isValid = false;
        }
        else if (!alphaNumericPattern.test(endLocation)) {
            endLocationError.textContent = "End Location may contain only letters, numbers, spaces, and hyphens.";
            isValid = false;
        }
        // Distance Validation
        const distance = document.getElementById("distance").value.trim();
        const distanceError = document.getElementById("distanceError");
        distanceError.textContent = ""; // Clear previous error
        if (!distance || distance <= 0) {
            distanceError.textContent = "Distance must be greater than 0.";
            isValid = false;
        }

        // Elevation Gain Validation
        const elevationGain = document.getElementById("elevationGain").value.trim();
        const elevationGainError = document.getElementById("elevationGainError");
        elevationGainError.textContent = ""; // Clear previous error
        if (!elevationGain || elevationGain <= 0) {
            elevationGainError.textContent = "Elevation Gain must be greater than 0.";
            isValid = false;
        }

        // Difficulty Level Validation
        const difficultyLevel = document.getElementById("difficultyLevel").value;
        const difficultyLevelError = document.getElementById("difficultyLevelError");
        difficultyLevelError.textContent = ""; // Clear previous error
        if (!difficultyLevel) {
            difficultyLevelError.textContent = "Please select a Difficulty Level.";
            isValid = false;
        }

        // Trail Type Validation
        const trailType = document.getElementById("trailType").value;
        const trailTypeError = document.getElementById("trailTypeError");
        trailTypeError.textContent = ""; // Clear previous error
        if (!trailType) {
            trailTypeError.textContent = "Please select a Trail Type.";
            isValid = false;
        }

        // Estimated Time Validation
        const estimatedTime = document.getElementById("estimatedTime").value.trim();
        const estimatedTimeError = document.getElementById("estimatedTimeError");
        estimatedTimeError.textContent = ""; // Clear previous error
        if (!estimatedTime || estimatedTime <= 0) {
            estimatedTimeError.textContent = "Estimated Time must be greater than 0.";
            isValid = false;
        }

        //trial conditions Validation
        if (!document.querySelector('input[name="trailCondition"]:checked')) {
            trailConditionError.textContent = "Please select at least one Trail Condition.";
            isCorrect = false;
        }

         // Validating Accessibility (select at least one checkbox)
        if (!document.querySelector('input[name="accessibility"]:checked')) {
        accessibilityError.textContent = "Please select at least one Accessibility option.";
        isCorrect = false;
       }




        // Prevent form submission if validation fails
        if (!isValid) {
            e.preventDefault();
        }
    });
});