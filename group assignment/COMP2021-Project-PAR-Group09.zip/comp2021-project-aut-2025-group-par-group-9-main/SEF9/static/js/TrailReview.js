document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const trailNameInput = document.getElementById('trailName2');
    const ratingInput = document.getElementById('rating');
    const reviewCommentInput = document.getElementById('reviewComment');

    review.addEventListener('submit', function (e) {
        let isValid = true;

        const trailName = trailNameInput.value.trim();
        const rating = parseInt(ratingInput.value);
        const reviewComment = reviewCommentInput.value.trim();

       const trailNameError = document.getElementById("trailNameError");  
         const ratingError = document.getElementById("ratingError");
            const reviewCommentError = document.getElementById("reviewCommentError");  

        const namePattern = /^[a-zA-Z0-9\s\-]+$/;
        const commentPattern = /^[a-zA-Z0-9\s\.,\-!?"']*$/;



        // Validate Trail Name
        trailNameError.textContent = "";
        if(!trailName){
            trailNameError.textContent = "Please enter a trail name.";
            isValid = false;
        }
        else if (!namePattern.test(trailName)) {
            trailNameError.textContent = "Trail Name can only contain letters, numbers, spaces, and hyphens.";
            isValid = false;
        }

        // Validate Rating
        ratingError.textContent = "";
        if (!rating) {
            ratingError.textContent = "Please enter a rating.";
            isValid = false;
        }
        else if (isNaN(rating) || rating < 1 || rating > 5) {
          ratingError.textContent=  "Rating must be a number between 1 and 5.";
            isValid = false;
        }

        // Validate Review Comment (optional)
        reviewCommentError.textContent = "";
        if(!reviewComment) {
            reviewCommentError.textContent = "Please enter a review comment.";
            isValid = false;
        } else if (reviewComment.length > 0 && !commentPattern.test(reviewComment)) {
         reviewCommentError.textContent ="Review Comment can only contain letters, numbers, spaces, and common punctuation.";
            isValid = false;
        }

        // Final confirmation
        if (!isValid) {
            e.preventDefault(); // Prevent form submission if validation fails
        }
    });     
});
