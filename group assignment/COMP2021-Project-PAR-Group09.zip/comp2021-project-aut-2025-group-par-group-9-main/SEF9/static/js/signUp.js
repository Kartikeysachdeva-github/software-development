// Sign Up:
document.addEventListener("DOMContentLoaded", function () {
    const signUpForm = document.querySelector(".signUP form");

    signUpForm.addEventListener("submit", function (e) {
        let isValid = true;

        const username = document.getElementById("username").value.trim();
        const email = document.getElementById("emailSignUp").value.trim();
        const password = document.getElementById("passwordSignUp").value;
        const confirmPassword = document.getElementById("confirmPassword").value;

        const usernameError = document.getElementById("usernameError");
        const emailError = document.getElementById("emailError");
        const passwordError = document.getElementById("passwordError");
        const confirmPasswordError = document.getElementById("confirmPasswordError");


        const usernamePattern = /^[a-zA-Z0-9_]{3,20}$/;
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        // Password pattern: at least 6 characters, at least one upper case letter, one lower case letter, one special character, and one number
        const passwordPattern =/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{10,}$/
        const passwordPatternLower = /^(?=.*[a-z])/;
        const passwordPatternUpper = /^(?=.*[A-Z])/;
        const passwordPatternDigit = /^(?=.*\d)/;
        const passwordPatternSpecial = /^(?=.*[@$!%*?&])/;


        // Validate Username
        usernameError.textContent = ""; // Clear error message if valid
        if (!username) {
            usernameError.textContent = "Please enter a username.";
            isValid = false;
        } else if (!usernamePattern.test(username)) {
            
         usernameError.textContent="Username must be 3-20 characters and contain only letters, numbers, or underscores.";
            isValid = false;
        }

        // Validate Email
        emailError.textContent = "";
        if (!email) {
            emailError.textContent = "Please enter an e-mail address.";
            isValid = false;
        }
        else if (!emailPattern.test(email)) {
            emailError.textContent = "Please enter a valid e-mail address.";
            isValid = false;
        }

        // Validate Password
        passwordError.textContent = "";
        if (!password) {
            passwordError.textContent = "Please enter a password.";
            isValid = false;
        } else if (!passwordPattern.test(password)) {
            passwordError.textContent = "Password must be at least 10 characters long ";
            if (!passwordPatternLower.test(password)) {
                passwordError.textContent = " Password must contain at least one lower case letter.";
            }
            if (!passwordPatternUpper.test(password)) {
                passwordError.textContent = " Password must contain at least one upper case letter.";
            }
            if (!passwordPatternDigit.test(password)) {
                passwordError.textContent = " Password must contain at least one digit.";
            }
            if (!passwordPatternSpecial.test(password)) {
                passwordError.textContent = " Password must contain at least one special character.";
            }
            isValid = false;
        }

        // Validate Confirm Password
        confirmPasswordError.textContent = "";

        if (password !== confirmPassword) {
            confirmPasswordError.textContent = "Passwords do not match.";
            isValid = false;
        }
        else if (!confirmPassword) {
            confirmPasswordError.textContent = "Please confirm your password.";
            isValid = false;
        }

        // Prevent form submission if any validation fails
        if (!isValid) {
            e.preventDefault();
        }
        
    });
});